//
//  ProtocolController.h
//  studentBuzz
//
//  Created by Muneeb on 4/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "authProtocol.h"
@interface ProtocolController : UIViewController<authProtocol>

@end
